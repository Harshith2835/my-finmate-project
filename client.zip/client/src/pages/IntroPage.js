export default function IntroPage(){
    return (<>
        Here's the intro page where we tell about ourselves. It appears prior to user login and after logout.
    </>);
}